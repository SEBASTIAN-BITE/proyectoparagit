<?php include 'includes/header.php';?>
<?php include 'includes/database.php';?>
<h2>Ultimas Publicaciones</h2>

<?php
$query="SELECT * FROM publicaciones ORDER BY Fecha desc";
$result=$conn->query($query);
if($result->num_rows > 0)
{
    while($row=$result->fetch_assoc()){
        echo '<div class= "card mb.3">';
        echo '<div class= "card-boby">';
        echo '<h5 class= "card-title">'.$row['Titulo'].'</h5>';
        echo '<p class="card-text">'.substr($row['Contenido'],0,150).'...</p>';
        echo '<small class="text-muted">'.$row['Fecha'].'</small>';
        echo '</div>';
        echo '</div>';
    }
}else{
    echo '<p class="text-muted">No hay publicaciones</p>';
}
$conn->close()
?>
