<?php
$host = 'localhost';
$usuario = 'root'; //usuario de mysql sue
$Contrasena ='';
$base_datos = 'blog';

//crear conexcion a las base de datos utilizando mysql
$conn=new mysqli($host,$usuario,$Contrasena,$base_datos);
if ($conn->connect_error)
{
    die('error de conexcion: '. $conn->connect_error);
}
$conn->set_charset("utf8");
?>